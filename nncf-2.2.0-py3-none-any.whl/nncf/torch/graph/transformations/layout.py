from nncf.common.graph.transformations.layout import TransformationLayout


class PTTransformationLayout(TransformationLayout):
    pass
